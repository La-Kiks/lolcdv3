create view pg_roles
            (rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb, rolcanlogin, rolreplication, rolconnlimit,
             rolpassword, rolvaliduntil, rolbypassrls, rolconfig, oid)
as
SELECT pg_authid.rolname,
       pg_authid.rolsuper,
       pg_authid.rolinherit,
       pg_authid.rolcreaterole,
       pg_authid.rolcreatedb,
       pg_authid.rolcanlogin,
       pg_authid.rolreplication,
       pg_authid.rolconnlimit,
       '********'::text AS rolpassword,
       pg_authid.rolvaliduntil,
       pg_authid.rolbypassrls,
       s.setconfig      AS rolconfig,
       pg_authid.oid
FROM pg_authid
         LEFT JOIN pg_db_role_setting s ON pg_authid.oid = s.setrole AND s.setdatabase = 0::oid;

alter table pg_roles
    owner to app;

grant select on pg_roles to public;

