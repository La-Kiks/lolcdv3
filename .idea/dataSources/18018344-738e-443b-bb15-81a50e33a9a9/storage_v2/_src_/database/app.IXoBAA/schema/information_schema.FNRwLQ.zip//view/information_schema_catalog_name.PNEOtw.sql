create view information_schema_catalog_name(catalog_name) as
SELECT current_database()::information_schema.sql_identifier AS catalog_name;

alter table information_schema_catalog_name
    owner to app;

grant select on information_schema_catalog_name to public;

