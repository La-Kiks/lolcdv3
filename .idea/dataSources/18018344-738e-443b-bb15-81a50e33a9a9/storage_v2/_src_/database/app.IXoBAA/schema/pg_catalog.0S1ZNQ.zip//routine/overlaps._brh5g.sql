create function "overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, interval) returns boolean
    stable
    parallel safe
    cost 1
    language sql
RETURN (($1, $2) OVERLAPS ($3, ($3 + $4)));

comment on function "overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, interval) is 'intervals overlap?';

alter function "overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, interval) owner to app;

