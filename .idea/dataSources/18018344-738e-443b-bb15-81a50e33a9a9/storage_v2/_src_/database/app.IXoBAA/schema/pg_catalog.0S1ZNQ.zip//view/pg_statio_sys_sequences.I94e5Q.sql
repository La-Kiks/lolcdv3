create view pg_statio_sys_sequences(relid, schemaname, relname, blks_read, blks_hit) as
SELECT relid,
       schemaname,
       relname,
       blks_read,
       blks_hit
FROM pg_statio_all_sequences
WHERE (schemaname = ANY (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
   OR schemaname ~ '^pg_toast'::text;

alter table pg_statio_sys_sequences
    owner to app;

grant select on pg_statio_sys_sequences to public;

