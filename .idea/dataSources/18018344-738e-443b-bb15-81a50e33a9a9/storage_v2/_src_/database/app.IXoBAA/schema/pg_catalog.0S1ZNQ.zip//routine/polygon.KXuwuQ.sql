create function polygon(circle) returns polygon
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN polygon(12, $1);

comment on function polygon(circle) is 'convert circle to 12-vertex polygon';

alter function polygon(circle) owner to app;

